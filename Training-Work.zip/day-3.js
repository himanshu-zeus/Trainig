function reset()
{
    console.log("reset form");
    document.getElementById("form1").reset();
}